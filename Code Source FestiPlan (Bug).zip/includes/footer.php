<footer>
        <p>&copy; <?php echo date("Y"); ?> Planificateur de Fêtes</p>
        <p>Tous droits réservés.</p>
</footer>